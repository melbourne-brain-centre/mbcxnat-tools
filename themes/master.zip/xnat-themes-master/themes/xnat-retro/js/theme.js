/* Default js file for XNAT "Retro" theme */

console.log('xnat-retro');
